package model

// BFSConf service bfs conf model
type BFSConf struct {
	Host         string
	AccessKey    string
	AccessSecret string
}
